
These are the Arduino sketches used to send the IMU data to the computer through the serial port.

Arduino sketches for each of the IMUs y used:
- gy88_2arduino2rpi
- mpu6050_2arduino2rpi
- adafruitIMU9dof_2arduino2rpi

Arduino Libraries I used to request data by i2c (https://github.com/jrowberg/i2cdevlib/tree/master/Arduino):
- arduinoLibraries
